<?php

$config = [

		
		
									
		'signin'			=>	[
														[
															'field'	=>	'username',
															'label'	=>	'Phone Number',
															'rules'	=>	'trim|required|numeric|min_length[10]',
														],
														[
															'field'	=>	'password',
															'label'	=>	'Password',
															'rules'	=>	'required',
														]
									],
		
									
        
				 

];