<html>
<head>
<title>
hello
</title>
</head>
<body>
<h1> welcome to learn Ecommerce Website.</h1>
<h2>In this we re Learn to create a ecommerce website and how to create a cart system and how to place order in cart.</h2>
<h3>
we are creating a admin panel to maintain data like add, update, delete of data. add product, ordered history, product category...etc.
</h3>
<h4>
in this project also learn how to upload website in live server through domain and hosting.
</h4>
 
</body>
</html>
