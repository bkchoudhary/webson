<?php
    
    class Articlesmodel extends CI_Model{
    	
   //----------------------		shoe shop      -------------------------------------------------
		
	
			
	
	
	
	
	}	
	
	
	
	
	
	
	
	
	
    
   ?>
    